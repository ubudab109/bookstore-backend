export enum OrderStatus {
  PROCESS = 'process',
  PAID = 'paid',
}

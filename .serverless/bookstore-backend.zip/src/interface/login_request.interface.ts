export interface LoginRequestI {
  username: string;
  password: string;
}
